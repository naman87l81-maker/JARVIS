# JARVIS (Android AI voice operator)

Native Android app (Kotlin, Jetpack Compose, Material 3). Minimum Android 10 (API 29).
Built one milestone at a time from `BUILD_SPEC.md`. Current: Milestone 2 (voice loop).
See `IMPLEMENTATION_STATUS.md` for what is verified and what is not.

## Build with GitHub Actions (no PC needed)
Sources are in `project.zip`; `.github/workflows/build.yml` unpacks and builds it.
Download the `jarvis-debug-apk` artifact from the Actions tab, unzip, install `app-debug.apk`.

## Set up the AI provider
Settings -> AI provider. Use a free key from Groq (console.groq.com) or OpenRouter. Never commit keys.
