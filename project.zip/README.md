# JARVIS (Android AI voice operator)

Native Android app (Kotlin, Jetpack Compose, Material 3). Minimum Android 10 (API 29).
This repository follows `BUILD_SPEC.md`, built one milestone at a time.

**Current: Milestone 1, native foundation.** See `IMPLEMENTATION_STATUS.md` for what works.

## Build with GitHub Actions (no PC needed)
1. The project sources are in `project.zip`; the workflow `.github/workflows/build.yml` unpacks and builds it.
2. Open the repo's **Actions** tab, open the latest run, download the `jarvis-debug-apk` artifact.
3. Unzip it and install `app-debug.apk` (allow installs from unknown sources).

## Build locally (Android Studio)
Unzip `project.zip`, open the folder in Android Studio, run the `app` configuration.

## API keys
None needed yet. Provider keys arrive in Milestone 3 and are entered by the user in Settings. Never commit keys.
