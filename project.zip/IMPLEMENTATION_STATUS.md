# Implementation status (Milestone 2: voice loop, with minimal provider setup)

Verified on a real device (Redmi Pad 2): the Milestone 1 screens (home, call screen, End call).
Everything below marked "written" has NOT been built or run yet. It becomes "verified"
only after a green CI build and a successful test on the device.

## Written, awaiting device test
- Microphone permission flow (explanation, Allow, Open app settings, re-check on return)
- Speech input via Android SpeechRecognizer: partial text shown, only the final sentence is sent to the AI
- AI chat through any OpenAI-compatible endpoint (Groq, OpenRouter): 401/403/404/429/5xx, network and
  timeout errors handled; up to 3 attempts with backoff; honours Retry-After (waits up to 15 s)
- Spoken replies via Android TextToSpeech, sentence by sentence
- Interrupt button: stops speech or cancels a request still waiting for the AI, then listens again
- Stale-reply protection: replies that arrive after an interruption or End call are ignored
- End call stops speech, cancels the request, releases the recognizer and speech engine
- The call ends automatically if the app leaves the screen (microphone closes)
- Mute, transcript (partial + final lines), mic status pill, call timer
- Settings: endpoint, model, API key (Android Keystore encrypted), Test connection, List models, Remove key,
  last request status
- Conversation history (memory only) shown on Home; delete-history action
- Unit tests: state machine, task repository, speech text, response parsing, conversation agent

## Partially working / limitations
- Replies are turn-based, not streamed. Speech starts after the full reply arrives.
- Interrupting by voice while JARVIS speaks is NOT implemented (the mic is off during speech to avoid
  echo). Use the Interrupt button.
- Speech recognition may need internet and may be handled by Google; this is up to the device.
- Provider usage/quota figures are not shown (Groq does not expose them in this client).
- Settings (theme, history) are not persisted across app restarts. Provider settings and key are.

## Not implemented
- Agent tools, approvals, cancellation of tools (Milestone 4)
- File generation (Milestone 5), web research (Milestone 6), screen assistance (Milestone 7)
- Android integrations and shortcuts (Milestone 8)
- Room database, DataStore, instrumentation tests
- Real-time WebRTC calling
