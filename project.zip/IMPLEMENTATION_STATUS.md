# Implementation status (Milestone 1)

Nothing here has been compiled or run on a device yet. "Written" means the source exists;
it becomes "verified" only after the first successful CI build and a run on a real device.

## Written (unverified until first build)
- Compose navigation: Home, Call, Tasks, Settings
- Home screen: avatar, Call button, status card, empty states for tasks, conversations, files
- Call screen: avatar, state label, call timer, audio-level bars, hideable transcript panel,
  task panel, Mute / Stop speech (disabled until voice exists), End call
- Call state machine with all nine states and validated transitions (unit-tested)
- In-memory task history model and repository (unit-tested), Delete task history action
- Theme choice (System / Light / Dark), held in memory only
- No permissions declared (no internet, no microphone)

## Partially working
- Call screen: tapping Call starts a session, then shows "Voice unavailable" with a clear reason,
  because no voice engine exists yet. End call and Back work and return to IDLE.

## Not implemented
- Microphone input, speech recognition, text-to-speech, interruption (Milestone 2)
- AI provider, API keys, networking (Milestone 3)
- Agent tools, approvals, cancellation (Milestone 4)
- TXT / Markdown / PDF generation (Milestone 5)
- Web research (Milestone 6)
- Screen assistance (Milestone 7)
- Android integrations, shortcuts (Milestone 8)
- Persistent storage (Room, DataStore), instrumentation tests
