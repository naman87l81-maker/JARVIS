# Changelog

## 0.1.0 (Milestone 1)
- Project foundation: Compose navigation, Home, Call, Tasks and Settings screens
- Call state machine, in-memory task history, theme choice
