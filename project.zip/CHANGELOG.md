# Changelog

## 0.2.0 (Milestone 2)
- Real voice loop: microphone permission, Android speech recognition, AI reply, spoken output
- Interrupt, mute, End call with resource release, stale-reply protection
- AI provider settings with Keystore-encrypted API key, connection test and model list
- In-memory conversation history on Home

## 0.1.0 (Milestone 1)
- Project foundation: Compose navigation, Home, Call, Tasks and Settings screens
- Call state machine, in-memory task history, theme choice
