package com.jarvis.assistant.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatMessage(val role: String, val content: String)

data class ProviderConfig(
    val endpoint: String,
    val model: String,
    val apiKey: String?
) {
    val isComplete: Boolean
        get() = endpoint.isNotBlank() && model.isNotBlank() && !apiKey.isNullOrBlank()
}

enum class FailureKind {
    NOT_CONFIGURED,
    UNAUTHORIZED,
    FORBIDDEN,
    NOT_FOUND,
    RATE_LIMITED,
    SERVER,
    NETWORK,
    TIMEOUT,
    BAD_RESPONSE,
    OTHER
}

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Failure(val kind: FailureKind, val message: String) : AiResult()
}

sealed class ModelsResult {
    data class Success(val ids: List<String>) : ModelsResult()
    data class Failure(val message: String) : ModelsResult()
}

interface AiProvider {
    suspend fun chat(messages: List<ChatMessage>): AiResult
    suspend fun listModels(): ModelsResult
}

/** Human-readable outcome of the most recent provider request, shown in Settings. */
object ProviderStatus {
    private val _last = MutableStateFlow("No requests yet.")
    val last: StateFlow<String> = _last.asStateFlow()

    fun record(text: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _last.value = "$text ($time)"
    }
}
