package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Wraps Android's SpeechRecognizer. Must be used from the main thread.
 * Only final results are meant to be sent to the AI; partial results are for display.
 */
class SpeechInput(
    private val context: Context,
    private val callback: Callback
) {
    interface Callback {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onNoSpeech()
        fun onError(message: String)
        fun onLevel(level: Float)
    }

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start() {
        stop()
        val created = SpeechRecognizer.createSpeechRecognizer(context)
        created.setRecognitionListener(listener)
        recognizer = created

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        created.startListening(intent)
    }

    /** Stops listening and releases the recognizer. Safe to call at any time. */
    fun stop() {
        val current = recognizer ?: return
        recognizer = null
        current.setRecognitionListener(null)
        current.cancel()
        current.destroy()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            callback.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            when (error) {
                // 6 = speech timeout, 7 = no match: normal when nobody spoke
                6, 7 -> callback.onNoSpeech()
                9 -> callback.onError("Microphone permission is missing. Allow it and try again.")
                1, 2, 4 -> callback.onError(
                    "Speech recognition couldn't reach its service. Check your internet connection."
                )
                3 -> callback.onError("The microphone couldn't record audio. Is another app using it?")
                8 -> callback.onError("The speech recognizer is busy. Try again in a moment.")
                12, 13 -> callback.onError("Speech recognition doesn't support this language on this device.")
                else -> callback.onError("Speech recognition failed (code $error). Try again.")
            }
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isBlank()) callback.onNoSpeech() else callback.onFinal(text)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isNotBlank()) callback.onPartial(text)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
