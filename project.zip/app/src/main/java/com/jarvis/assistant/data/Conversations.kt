package com.jarvis.assistant.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Speaker { USER, JARVIS }

data class TranscriptLine(val speaker: Speaker, val text: String)

data class ConversationRecord(
    val id: String,
    val startedAtMillis: Long,
    val lines: List<TranscriptLine>
)

/** In-memory conversation history. Room persistence arrives in a later milestone. */
class ConversationRepository {
    private val _conversations = MutableStateFlow<List<ConversationRecord>>(emptyList())
    val conversations: StateFlow<List<ConversationRecord>> = _conversations.asStateFlow()

    fun add(record: ConversationRecord) {
        _conversations.update { current -> listOf(record) + current }
    }

    fun clear() {
        _conversations.value = emptyList()
    }
}
