package com.jarvis.assistant.agent

import com.jarvis.assistant.ai.AiProvider
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.ai.ChatMessage

/**
 * Turn-based conversation. It only talks: no tools exist yet (Milestone 4), and the
 * system prompt says so, so the model does not claim abilities JARVIS does not have.
 */
class ConversationAgent(private val provider: AiProvider) {
    private val history = ArrayList<ChatMessage>()

    suspend fun respond(userText: String): AiResult {
        val messages = ArrayList<ChatMessage>()
        messages.add(ChatMessage("system", SYSTEM_PROMPT))
        messages.addAll(history.takeLast(MAX_HISTORY_MESSAGES))
        messages.add(ChatMessage("user", userText))
        return provider.chat(messages)
    }

    /** Call only for a reply that is actually used, so cancelled or stale replies leave no trace. */
    fun record(userText: String, reply: String) {
        history.add(ChatMessage("user", userText))
        history.add(ChatMessage("assistant", reply))
    }

    fun reset() {
        history.clear()
    }

    companion object {
        const val MAX_HISTORY_MESSAGES = 20

        const val SYSTEM_PROMPT =
            "You are JARVIS, a voice assistant inside an Android app. Your replies are read aloud, " +
                "so answer in short, plain sentences with no markdown, lists or emojis. " +
                "Usually use one to three sentences. " +
                "Right now you can only talk. You cannot create files, browse the web, see the screen " +
                "or control the phone yet. If asked to do those things, say they are not available yet. " +
                "Never claim to have done something you cannot do. If you are unsure, say so."
    }
}
