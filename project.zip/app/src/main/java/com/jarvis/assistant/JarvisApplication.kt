package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.di.AppContainer

class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContainer.init(this)
    }
}
