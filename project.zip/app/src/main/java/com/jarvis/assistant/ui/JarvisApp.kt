package com.jarvis.assistant.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.data.AppSettings
import com.jarvis.assistant.ui.theme.JarvisTheme

object Routes {
    const val HOME = "home"
    const val CALL = "call"
    const val SETTINGS = "settings"
    const val TASKS = "tasks"
}

@Composable
fun JarvisApp() {
    val themeMode by AppSettings.themeMode.collectAsState()

    JarvisTheme(mode = themeMode) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = Routes.HOME) {
            composable(Routes.HOME) {
                HomeScreen(
                    onCall = { nav.navigate(Routes.CALL) },
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onTasks = { nav.navigate(Routes.TASKS) }
                )
            }
            composable(Routes.CALL) {
                CallScreen(onExit = { nav.popBackStack() })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { nav.popBackStack() })
            }
            composable(Routes.TASKS) {
                TasksScreen(onBack = { nav.popBackStack() })
            }
        }
    }
}
