package com.jarvis.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Wraps Android TextToSpeech. Replies are queued as sentence chunks tagged with a token,
 * so the caller can ignore anything that finishes after it has moved on.
 */
class SpeechOutput(
    context: Context,
    private val listener: Listener
) {
    interface Listener {
        /** The last chunk of the reply for this token finished playing. */
        fun onFinished(token: Long)

        /** Speech can't be played (engine missing, language missing, or playback failed). */
        fun onUnavailable(message: String)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failedMessage: String? = null
    private var pendingChunks: List<String>? = null
    private var pendingToken = 0L

    private val progressListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            val parts = utteranceId?.split(":") ?: return
            if (parts.size != 3) return
            val token = parts[0].toLongOrNull() ?: return
            val index = parts[1].toIntOrNull() ?: return
            val total = parts[2].toIntOrNull() ?: return
            if (index == total - 1) mainHandler.post { listener.onFinished(token) }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            playbackFailed()
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            playbackFailed()
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status -> onInit(status) }
    }

    fun speak(chunks: List<String>, token: Long) {
        if (chunks.isEmpty()) {
            listener.onFinished(token)
            return
        }
        val failure = failedMessage
        when {
            failure != null -> listener.onUnavailable(failure)
            !ready -> {
                pendingChunks = chunks
                pendingToken = token
            }
            else -> enqueue(chunks, token)
        }
    }

    /** Stops playback immediately and drops anything queued. */
    fun stop() {
        pendingChunks = null
        tts?.stop()
    }

    fun shutdown() {
        mainHandler.removeCallbacksAndMessages(null)
        pendingChunks = null
        val engine = tts
        tts = null
        ready = false
        engine?.stop()
        engine?.shutdown()
    }

    private fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            fail("The speech engine could not start, so replies will be shown as text only.")
            return
        }
        var result = engine.setLanguage(Locale.getDefault())
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            result = engine.setLanguage(Locale.US)
        }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            fail("No speech voice is installed for your language, so replies will be shown as text only.")
            return
        }
        engine.setOnUtteranceProgressListener(progressListener)
        ready = true

        val chunks = pendingChunks
        if (chunks != null) {
            pendingChunks = null
            enqueue(chunks, pendingToken)
        }
    }

    private fun fail(message: String) {
        failedMessage = message
        if (pendingChunks != null) {
            pendingChunks = null
            listener.onUnavailable(message)
        }
    }

    private fun enqueue(chunks: List<String>, token: Long) {
        val engine = tts ?: return
        engine.stop()
        chunks.forEachIndexed { index, chunk ->
            val id = "$token:$index:${chunks.size}"
            val code = engine.speak(chunk, TextToSpeech.QUEUE_ADD, null, id)
            if (code == TextToSpeech.ERROR) {
                listener.onUnavailable("The speech engine refused to speak, so the reply is shown as text.")
                return
            }
        }
    }

    private fun playbackFailed() {
        mainHandler.post {
            tts?.stop()
            listener.onUnavailable("Speech playback failed, so the reply is shown as text.")
        }
    }
}
