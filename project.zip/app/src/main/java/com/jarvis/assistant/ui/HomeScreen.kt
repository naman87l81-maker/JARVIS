package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.di.AppContainer

@Composable
fun HomeScreen(
    onCall: () -> Unit,
    onSettings: () -> Unit,
    onTasks: () -> Unit
) {
    val tasks by AppContainer.taskRepository.tasks.collectAsState()
    val conversations by AppContainer.conversationRepository.conversations.collectAsState()
    val providerReady = AppContainer.providerConfigured()

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(onClick = onSettings) {
                            Icon(Icons.Filled.Settings, contentDescription = "Settings")
                        }
                    }
                }
                item { JarvisAvatar(size = 104.dp) }
                item {
                    Text(
                        text = "JARVIS",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                item {
                    Text(
                        text = "Your AI voice operator",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                item {
                    Button(
                        onClick = onCall,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Call JARVIS", style = MaterialTheme.typography.titleMedium)
                    }
                }
                item {
                    SectionCard("Status") {
                        StatusRow(
                            "AI provider",
                            if (providerReady) "Ready (${AppContainer.providerSettings.model})" else "Not set up"
                        )
                        StatusRow("Voice", "Android speech and text-to-speech")
                        StatusRow("Network", "Only to your AI provider")
                        if (!providerReady) {
                            TextButton(onClick = onSettings) { Text("Set up AI provider") }
                        }
                    }
                }
                item {
                    SectionCard("Recent tasks") {
                        if (tasks.isEmpty()) {
                            Text(
                                "No tasks yet. Tasks appear here once JARVIS can run tools (Milestone 4).",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            tasks.take(3).forEach { TaskRow(it) }
                        }
                        TextButton(onClick = onTasks) { Text("View all tasks") }
                    }
                }
                item {
                    SectionCard("Recent conversations") {
                        if (conversations.isEmpty()) {
                            Text(
                                "No conversations yet. Tap Call JARVIS to start one.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            conversations.take(3).forEach { c ->
                                Text(
                                    "${formatTime(c.startedAtMillis)}: ${c.lines.size} messages",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Text(
                                "Kept in memory only. Cleared when the app closes.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    SectionCard("Generated files") {
                        Text(
                            "No files yet. Documents JARVIS creates will be listed here (Milestone 5).",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
