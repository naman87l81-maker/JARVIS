package com.jarvis.assistant.di

import com.jarvis.assistant.data.TaskRepository
import com.jarvis.assistant.voice.NotImplementedVoiceEngine
import com.jarvis.assistant.voice.VoiceEngine

/** Simple constructor-injection root. Later milestones swap in real implementations here. */
object AppContainer {
    val taskRepository: TaskRepository = TaskRepository()
    val voiceEngine: VoiceEngine = NotImplementedVoiceEngine()
}
