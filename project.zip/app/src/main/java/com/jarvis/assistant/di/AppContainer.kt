package com.jarvis.assistant.di

import android.app.Application
import android.content.Context
import com.jarvis.assistant.ai.AiProvider
import com.jarvis.assistant.ai.OpenAiCompatibleProvider
import com.jarvis.assistant.ai.ProviderConfig
import com.jarvis.assistant.data.ConversationRepository
import com.jarvis.assistant.data.ProviderSettingsStore
import com.jarvis.assistant.data.TaskRepository
import com.jarvis.assistant.security.SecretStore

/** Simple wiring root. Initialised once from JarvisApplication. */
object AppContainer {
    private var application: Application? = null

    fun init(app: Application) {
        application = app
    }

    val appContext: Context
        get() = checkNotNull(application) { "AppContainer.init was not called" }

    val taskRepository: TaskRepository = TaskRepository()
    val conversationRepository: ConversationRepository = ConversationRepository()

    val secretStore: SecretStore by lazy { SecretStore(appContext) }
    val providerSettings: ProviderSettingsStore by lazy { ProviderSettingsStore(appContext) }
    val aiProvider: AiProvider by lazy { OpenAiCompatibleProvider({ currentConfig() }) }

    fun currentConfig(): ProviderConfig = ProviderConfig(
        endpoint = providerSettings.endpoint,
        model = providerSettings.model,
        apiKey = secretStore.get(SecretStore.PROVIDER_KEY)
    )

    fun providerConfigured(): Boolean = currentConfig().isComplete
}
