package com.jarvis.assistant.voice

/** Boundary for microphone input and speech output. Milestone 2 provides a real implementation. */
interface VoiceEngine {
    /** Returns null when voice is available, otherwise a plain-language reason it is not. */
    fun unavailableReason(): String?
}

class NotImplementedVoiceEngine : VoiceEngine {
    override fun unavailableReason(): String? =
        "Voice is not built yet. Microphone and speech arrive in Milestone 2."
}
