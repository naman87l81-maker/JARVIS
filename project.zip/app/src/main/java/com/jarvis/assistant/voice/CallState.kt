package com.jarvis.assistant.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CallState {
    IDLE,
    CONNECTING,
    LISTENING,
    PROCESSING,
    AWAITING_APPROVAL,
    EXECUTING,
    SPEAKING,
    ERROR,
    ENDING
}

/**
 * Explicit call state machine. Invalid transitions are rejected (returns false),
 * which also prevents a second call session from starting while one is active.
 */
class CallStateMachine {
    private val _state = MutableStateFlow(CallState.IDLE)
    val state: StateFlow<CallState> = _state.asStateFlow()

    fun canTransition(to: CallState): Boolean =
        ALLOWED[_state.value]?.contains(to) == true

    @Synchronized
    fun transition(to: CallState): Boolean {
        if (!canTransition(to)) return false
        _state.value = to
        return true
    }

    companion object {
        val ALLOWED: Map<CallState, Set<CallState>> = mapOf(
            CallState.IDLE to setOf(CallState.CONNECTING),
            CallState.CONNECTING to setOf(
                CallState.LISTENING, CallState.ERROR, CallState.ENDING
            ),
            CallState.LISTENING to setOf(
                CallState.PROCESSING, CallState.ERROR, CallState.ENDING
            ),
            CallState.PROCESSING to setOf(
                CallState.AWAITING_APPROVAL, CallState.EXECUTING, CallState.SPEAKING,
                CallState.LISTENING, CallState.ERROR, CallState.ENDING
            ),
            CallState.AWAITING_APPROVAL to setOf(
                CallState.EXECUTING, CallState.LISTENING, CallState.ERROR, CallState.ENDING
            ),
            CallState.EXECUTING to setOf(
                CallState.PROCESSING, CallState.SPEAKING, CallState.LISTENING,
                CallState.ERROR, CallState.ENDING
            ),
            CallState.SPEAKING to setOf(
                CallState.LISTENING, CallState.PROCESSING, CallState.ERROR, CallState.ENDING
            ),
            CallState.ERROR to setOf(
                CallState.CONNECTING, CallState.LISTENING, CallState.ENDING
            ),
            CallState.ENDING to setOf(CallState.IDLE)
        )
    }
}
