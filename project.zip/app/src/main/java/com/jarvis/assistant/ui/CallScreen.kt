package com.jarvis.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.data.Speaker
import com.jarvis.assistant.data.isActive
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.voice.CallState
import com.jarvis.assistant.voice.CallViewModel

private fun stateLabel(state: CallState): String = when (state) {
    CallState.IDLE -> "Idle"
    CallState.CONNECTING -> "Connecting"
    CallState.LISTENING -> "Listening"
    CallState.PROCESSING -> "Thinking"
    CallState.AWAITING_APPROVAL -> "Waiting for your approval"
    CallState.EXECUTING -> "Working on it"
    CallState.SPEAKING -> "Speaking"
    CallState.ERROR -> "Needs attention"
    CallState.ENDING -> "Ending call"
}

private fun formatDuration(totalSeconds: Int): String =
    "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)

private fun micGranted(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

@Composable
fun CallScreen(
    onExit: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: CallViewModel = viewModel()
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()
    val error by viewModel.errorMessage.collectAsState()
    val seconds by viewModel.durationSeconds.collectAsState()
    val muted by viewModel.muted.collectAsState()
    val partial by viewModel.partialText.collectAsState()
    val level by viewModel.audioLevel.collectAsState()
    val transcript by viewModel.transcript.collectAsState()
    val tasks by AppContainer.taskRepository.tasks.collectAsState()
    var showTranscript by remember { mutableStateOf(true) }
    var hasMic by remember { mutableStateOf(micGranted(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasMic = granted }

    // Re-check the permission when returning from system settings, and end the call
    // (closing the microphone) whenever the app is no longer on screen.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasMic = micGranted(context)
            } else if (event == Lifecycle.Event.ON_STOP && viewModel.state.value != CallState.IDLE) {
                viewModel.endCall()
                onExit()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasMic) {
        if (hasMic) viewModel.startCall()
    }
    BackHandler {
        viewModel.endCall()
        onExit()
    }

    val inCall = state == CallState.LISTENING ||
        state == CallState.PROCESSING ||
        state == CallState.AWAITING_APPROVAL ||
        state == CallState.EXECUTING ||
        state == CallState.SPEAKING

    val micLabel = when {
        state == CallState.LISTENING && !muted -> "Microphone on"
        inCall && muted -> "Microphone muted"
        else -> "Microphone off"
    }

    ScreenScaffold(scrollable = true) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            JarvisAvatar(size = 120.dp)
            Text(
                text = "JARVIS",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(text = stateLabel(state), isError = state == CallState.ERROR)
                StatusPill(text = micLabel)
            }
            Text(
                text = formatDuration(seconds),
                style = MaterialTheme.typography.titleLarge
            )
            AudioLevelBars(level = level)

            if (!hasMic) {
                SectionCard("Microphone needed") {
                    Text(
                        "JARVIS needs the microphone to hear you. Android's speech service turns your " +
                            "voice into text, and the microphone is only used while a call is open.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                        Text("Allow microphone")
                    }
                    OutlinedButton(onClick = {
                        val intent = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)
                        )
                        context.startActivity(intent)
                    }) { Text("Open app settings") }
                }
            }

            val message = error
            if (message != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (state == CallState.ERROR) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { viewModel.tryAgain() }) { Text("Try again") }
                                OutlinedButton(onClick = onOpenSettings) { Text("Settings") }
                            }
                        }
                    }
                }
            }

            if (showTranscript) {
                SectionCard("Transcript") {
                    if (transcript.isEmpty() && partial.isEmpty()) {
                        Text(
                            "Nothing yet. Start talking once it says Listening.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    transcript.takeLast(30).forEach { line ->
                        val who = if (line.speaker == Speaker.USER) "You" else "JARVIS"
                        Text("$who: ${line.text}", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (partial.isNotEmpty()) {
                        Text(
                            "You: $partial",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            SectionCard("Tasks") {
                val activeCount = tasks.count { it.status.isActive }
                Text(
                    text = if (activeCount == 0) "No active tasks" else "$activeCount active",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.toggleMute() },
                    enabled = inCall,
                    modifier = Modifier.weight(1f)
                ) { Text(if (muted) "Unmute" else "Mute") }
                OutlinedButton(
                    onClick = { viewModel.interrupt() },
                    enabled = state == CallState.SPEAKING || state == CallState.PROCESSING,
                    modifier = Modifier.weight(1f)
                ) { Text("Interrupt") }
                OutlinedButton(
                    onClick = { showTranscript = !showTranscript },
                    modifier = Modifier.weight(1f)
                ) { Text(if (showTranscript) "Hide text" else "Show text") }
            }

            Button(
                onClick = {
                    viewModel.endCall()
                    onExit()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                Text("End call", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
