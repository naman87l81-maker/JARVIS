package com.jarvis.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.data.isActive
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.voice.CallState
import com.jarvis.assistant.voice.CallViewModel

private fun stateLabel(state: CallState): String = when (state) {
    CallState.IDLE -> "Idle"
    CallState.CONNECTING -> "Connecting"
    CallState.LISTENING -> "Listening"
    CallState.PROCESSING -> "Thinking"
    CallState.AWAITING_APPROVAL -> "Waiting for your approval"
    CallState.EXECUTING -> "Working on it"
    CallState.SPEAKING -> "Speaking"
    CallState.ERROR -> "Voice unavailable"
    CallState.ENDING -> "Ending call"
}

private fun formatDuration(totalSeconds: Int): String =
    "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)

@Composable
fun CallScreen(
    onExit: () -> Unit,
    viewModel: CallViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()
    val error by viewModel.errorMessage.collectAsState()
    val seconds by viewModel.durationSeconds.collectAsState()
    val muted by viewModel.muted.collectAsState()
    val tasks by AppContainer.taskRepository.tasks.collectAsState()
    var showTranscript by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) { viewModel.startCall() }
    BackHandler {
        viewModel.endCall()
        onExit()
    }

    val inCall = state == CallState.LISTENING ||
        state == CallState.PROCESSING ||
        state == CallState.AWAITING_APPROVAL ||
        state == CallState.EXECUTING ||
        state == CallState.SPEAKING

    ScreenScaffold(scrollable = true) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            JarvisAvatar(size = 120.dp)
            Text(
                text = "JARVIS",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            StatusPill(text = stateLabel(state), isError = state == CallState.ERROR)
            Text(
                text = formatDuration(seconds),
                style = MaterialTheme.typography.titleLarge
            )
            AudioLevelBars(level = 0f)

            val message = error
            if (message != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = message,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (showTranscript) {
                SectionCard("Transcript") {
                    Text(
                        "Nothing yet. Your words and JARVIS's replies appear here once voice is connected (Milestone 2).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            SectionCard("Tasks") {
                val activeCount = tasks.count { it.status.isActive }
                Text(
                    text = if (activeCount == 0) "No active tasks" else "$activeCount active",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.toggleMute() },
                    enabled = inCall,
                    modifier = Modifier.weight(1f)
                ) { Text(if (muted) "Unmute" else "Mute") }
                OutlinedButton(
                    onClick = { viewModel.stopSpeech() },
                    enabled = state == CallState.SPEAKING,
                    modifier = Modifier.weight(1f)
                ) { Text("Stop speech") }
                OutlinedButton(
                    onClick = { showTranscript = !showTranscript },
                    modifier = Modifier.weight(1f)
                ) { Text(if (showTranscript) "Hide text" else "Show text") }
            }

            Button(
                onClick = {
                    viewModel.endCall()
                    onExit()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                Text("End call", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
