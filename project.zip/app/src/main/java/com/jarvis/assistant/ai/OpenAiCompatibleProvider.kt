package com.jarvis.assistant.ai

import java.io.IOException
import java.io.InterruptedIOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject

/**
 * Talks to any OpenAI-compatible endpoint (Groq, OpenRouter, ...).
 * Chat requests have no side effects, so bounded retries are safe here.
 */
class OpenAiCompatibleProvider(
    private val configSource: () -> ProviderConfig,
    private val client: OkHttpClient = defaultClient()
) : AiProvider {

    private sealed class Outcome {
        data class Http(val code: Int, val body: String, val retryAfterSeconds: Long?) : Outcome()
        data class Error(val kind: FailureKind, val message: String) : Outcome()
    }

    override suspend fun chat(messages: List<ChatMessage>): AiResult {
        val config = configSource()
        checkConfig(config)?.let { return it.also { f -> ProviderStatus.record("Not sent: ${f.message}") } }

        val payload = JSONObject()
            .put("model", config.model)
            .put("temperature", 0.5)
            .put("max_tokens", 400)
            .put(
                "messages",
                JSONArray().apply {
                    messages.forEach { m ->
                        put(JSONObject().put("role", m.role).put("content", m.content))
                    }
                }
            )
            .toString()

        val outcome = execute {
            Request.Builder()
                .url(config.endpoint.trim().trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer ${config.apiKey}")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
        }

        val result = when (outcome) {
            is Outcome.Error -> AiResult.Failure(outcome.kind, outcome.message)
            is Outcome.Http -> {
                if (outcome.code in 200..299) {
                    val reply = OpenAiParsing.parseReply(outcome.body)
                    if (reply != null) {
                        AiResult.Success(reply)
                    } else {
                        AiResult.Failure(FailureKind.BAD_RESPONSE, "The provider sent an empty or unreadable reply.")
                    }
                } else {
                    httpFailure(outcome)
                }
            }
        }
        ProviderStatus.record(
            when (result) {
                is AiResult.Success -> "Last request succeeded"
                is AiResult.Failure -> "Last request failed: ${result.message}"
            }
        )
        return result
    }

    override suspend fun listModels(): ModelsResult {
        val config = configSource()
        checkConfig(config, needModel = false)?.let { return ModelsResult.Failure(it.message) }

        val outcome = execute {
            Request.Builder()
                .url(config.endpoint.trim().trimEnd('/') + "/models")
                .header("Authorization", "Bearer ${config.apiKey}")
                .get()
                .build()
        }
        return when (outcome) {
            is Outcome.Error -> ModelsResult.Failure(outcome.message)
            is Outcome.Http -> {
                if (outcome.code in 200..299) {
                    val ids = OpenAiParsing.parseModelIds(outcome.body).filter { OpenAiParsing.isChatModel(it) }
                    if (ids.isEmpty()) ModelsResult.Failure("The provider returned no usable models.")
                    else ModelsResult.Success(ids)
                } else {
                    ModelsResult.Failure(httpFailure(outcome).message)
                }
            }
        }
    }

    private fun checkConfig(config: ProviderConfig, needModel: Boolean = true): AiResult.Failure? {
        val endpoint = config.endpoint.trim()
        return when {
            endpoint.isEmpty() ->
                AiResult.Failure(FailureKind.NOT_CONFIGURED, "No endpoint set. Open Settings.")
            !endpoint.startsWith("https://") ->
                AiResult.Failure(FailureKind.NOT_CONFIGURED, "The endpoint must start with https:// so your key is sent securely.")
            needModel && config.model.isBlank() ->
                AiResult.Failure(FailureKind.NOT_CONFIGURED, "No model chosen. Open Settings.")
            config.apiKey.isNullOrBlank() ->
                AiResult.Failure(FailureKind.NOT_CONFIGURED, "No API key saved. Open Settings.")
            else -> null
        }
    }

    private fun httpFailure(http: Outcome.Http): AiResult.Failure {
        val detail = OpenAiParsing.parseErrorMessage(http.body)
        val suffix = if (detail != null) " Provider says: $detail" else ""
        return when (http.code) {
            401 -> AiResult.Failure(FailureKind.UNAUTHORIZED, "The API key was rejected (401). Check it in Settings.$suffix")
            403 -> AiResult.Failure(FailureKind.FORBIDDEN, "Access denied (403). The key may not be allowed to use this model.$suffix")
            404 -> AiResult.Failure(FailureKind.NOT_FOUND, "Not found (404). Check the endpoint address and model name in Settings.$suffix")
            429 -> {
                val wait = http.retryAfterSeconds
                val hint = if (wait != null) " Try again in about $wait seconds." else " Wait a moment and try again."
                AiResult.Failure(FailureKind.RATE_LIMITED, "Rate limit or free quota reached (429).$hint Check your provider's limits.")
            }
            in 500..599 -> AiResult.Failure(FailureKind.SERVER, "The provider had a problem (${http.code}). Try again shortly.")
            else -> AiResult.Failure(FailureKind.OTHER, "The provider rejected the request (${http.code}).$suffix")
        }
    }

    /** One request with bounded retries and exponential backoff; respects Retry-After. */
    private suspend fun execute(build: () -> Request): Outcome = withContext(Dispatchers.IO) {
        var last: Outcome = Outcome.Error(FailureKind.OTHER, "No attempt was made.")
        for (attempt in 1..MAX_ATTEMPTS) {
            last = performOnce(build)
            val current = last
            val retryable = when (current) {
                is Outcome.Error -> true
                is Outcome.Http -> current.code == 429 || current.code in 500..599
            }
            if (!retryable || attempt == MAX_ATTEMPTS) break

            val waitMs = when (current) {
                is Outcome.Http -> current.retryAfterSeconds?.let { it * 1000L } ?: backoffMs(attempt)
                is Outcome.Error -> backoffMs(attempt)
            }
            if (waitMs > MAX_WAIT_MS) break
            delay(waitMs)
        }
        last
    }

    private suspend fun performOnce(build: () -> Request): Outcome {
        return try {
            client.newCall(build()).await().use { response ->
                Outcome.Http(
                    code = response.code,
                    body = response.body?.string().orEmpty(),
                    retryAfterSeconds = response.header("Retry-After")?.trim()?.toLongOrNull()
                )
            }
        } catch (e: InterruptedIOException) {
            Outcome.Error(FailureKind.TIMEOUT, "The provider took too long to answer.")
        } catch (e: IOException) {
            Outcome.Error(FailureKind.NETWORK, "Can't reach the provider. Check your internet connection.")
        }
    }

    private fun backoffMs(attempt: Int): Long = 1000L * (1L shl (attempt - 1))

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }

    companion object {
        private const val MAX_ATTEMPTS = 3
        private const val MAX_WAIT_MS = 15_000L

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .build()
    }
}
