package com.jarvis.assistant.voice

/** Prepares AI text for the speech engine. */
object SpeechText {

    fun cleanForSpeech(text: String): String =
        text.replace(Regex("[*_`#>]+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Splits a reply into sentence-sized chunks so speech can start and be interrupted quickly. */
    fun chunks(text: String, maxLen: Int = 400): List<String> {
        val cleaned = cleanForSpeech(text)
        if (cleaned.isEmpty()) return emptyList()

        val result = mutableListOf<String>()
        for (sentence in cleaned.split(Regex("(?<=[.!?\\u0964])\\s+"))) {
            var rest = sentence.trim()
            while (rest.length > maxLen) {
                var cut = rest.lastIndexOf(' ', maxLen)
                if (cut <= 0) cut = maxLen
                result.add(rest.substring(0, cut).trim())
                rest = rest.substring(cut).trim()
            }
            if (rest.isNotEmpty()) result.add(rest)
        }
        return result
    }
}
