package com.jarvis.assistant.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.ai.ChatMessage
import com.jarvis.assistant.ai.ModelsResult
import com.jarvis.assistant.data.ProviderSettingsStore
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.security.SecretStore
import kotlinx.coroutines.launch

class SettingsViewModel : ViewModel() {
    private val store = AppContainer.providerSettings
    private val secrets = AppContainer.secretStore
    private val provider = AppContainer.aiProvider

    var endpoint by mutableStateOf(store.endpoint)
    var model by mutableStateOf(store.model)
    var keyInput by mutableStateOf("")

    var hasKey by mutableStateOf(secrets.has(SecretStore.PROVIDER_KEY))
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var messageIsError by mutableStateOf(false)
        private set
    var models by mutableStateOf<List<String>>(emptyList())
        private set

    fun useGroqPreset() {
        endpoint = ProviderSettingsStore.GROQ_ENDPOINT
        model = ProviderSettingsStore.GROQ_DEFAULT_MODEL
        models = emptyList()
    }

    fun useOpenRouterPreset() {
        endpoint = ProviderSettingsStore.OPENROUTER_ENDPOINT
        model = ""
        models = emptyList()
    }

    fun save() {
        persist()
        show("Saved.", isError = false)
    }

    fun removeKey() {
        secrets.remove(SecretStore.PROVIDER_KEY)
        hasKey = false
        keyInput = ""
        show("API key removed from this device.", isError = false)
    }

    fun testConnection() {
        persist()
        viewModelScope.launch {
            busy = true
            message = null
            val result = provider.chat(
                listOf(ChatMessage("user", "Reply with the single word OK."))
            )
            busy = false
            when (result) {
                is AiResult.Success -> show("Connected. The model replied: ${result.text.take(60)}", false)
                is AiResult.Failure -> show(result.message, true)
            }
        }
    }

    fun loadModels() {
        persist()
        viewModelScope.launch {
            busy = true
            message = null
            when (val result = provider.listModels()) {
                is ModelsResult.Success -> {
                    models = result.ids
                    show("Found ${result.ids.size} chat models. Tap one to use it.", false)
                }
                is ModelsResult.Failure -> show(result.message, true)
            }
            busy = false
        }
    }

    fun pickModel(id: String) {
        model = id
        persist()
        show("Model set to $id.", false)
    }

    private fun persist() {
        store.endpoint = endpoint.trim()
        store.model = model.trim()
        val key = keyInput.trim()
        if (key.isNotEmpty()) {
            secrets.put(SecretStore.PROVIDER_KEY, key)
            keyInput = ""
            hasKey = true
        }
    }

    private fun show(text: String, isError: Boolean) {
        message = text
        messageIsError = isError
    }
}
