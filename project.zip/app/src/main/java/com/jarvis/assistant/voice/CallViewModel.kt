package com.jarvis.assistant.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.agent.ConversationAgent
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.data.ConversationRecord
import com.jarvis.assistant.data.Speaker
import com.jarvis.assistant.data.TranscriptLine
import com.jarvis.assistant.di.AppContainer
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Runs one call: listen, send the finished sentence to the AI, speak the reply, listen again.
 * All state changes go through CallStateMachine. Everything here runs on the main thread.
 */
class CallViewModel : ViewModel() {
    private val context = AppContainer.appContext
    private val machine = CallStateMachine()
    private val agent = ConversationAgent(AppContainer.aiProvider)

    private var speechInput: SpeechInput? = null
    private var speechOutput: SpeechOutput? = null
    private var timerJob: Job? = null
    private var requestJob: Job? = null
    private var startedAtMillis = 0L
    private var noSpeechStreak = 0

    /** Bumped on every interruption, cancellation or end of call. Results carrying an old value are ignored. */
    private var generation = 0L

    val state: StateFlow<CallState> = machine.state

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0)
    val durationSeconds: StateFlow<Int> = _durationSeconds.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _transcript = MutableStateFlow<List<TranscriptLine>>(emptyList())
    val transcript: StateFlow<List<TranscriptLine>> = _transcript.asStateFlow()

    private val inputCallback = object : SpeechInput.Callback {
        override fun onPartial(text: String) {
            if (machine.state.value == CallState.LISTENING) _partialText.value = text
        }

        override fun onFinal(text: String) {
            if (machine.state.value == CallState.LISTENING) handleUtterance(text)
        }

        override fun onNoSpeech() {
            if (machine.state.value == CallState.LISTENING) handleNoSpeech()
        }

        override fun onError(message: String) {
            if (machine.state.value == CallState.LISTENING) {
                speechInput?.stop()
                fail(message)
            }
        }

        override fun onLevel(level: Float) {
            if (machine.state.value == CallState.LISTENING) _audioLevel.value = level
        }
    }

    private val outputListener = object : SpeechOutput.Listener {
        override fun onFinished(token: Long) {
            if (token == generation && machine.state.value == CallState.SPEAKING) {
                machine.transition(CallState.LISTENING)
                beginListening()
            }
        }

        override fun onUnavailable(message: String) {
            if (machine.state.value == CallState.SPEAKING) {
                // Keep the call going: the reply is already in the transcript as text.
                _errorMessage.value = message
                machine.transition(CallState.LISTENING)
                beginListening()
            }
        }
    }

    fun startCall() {
        // Rejected unless IDLE, so a second session can never start.
        if (!machine.transition(CallState.CONNECTING)) return
        startedAtMillis = System.currentTimeMillis()
        _transcript.value = emptyList()
        _durationSeconds.value = 0
        agent.reset()
        connect()
    }

    fun tryAgain() {
        if (machine.state.value != CallState.ERROR) return
        _errorMessage.value = null
        noSpeechStreak = 0
        if (speechInput == null) {
            machine.transition(CallState.CONNECTING)
            connect()
        } else {
            machine.transition(CallState.LISTENING)
            startTimer()
            beginListening()
        }
    }

    private fun connect() {
        _errorMessage.value = null

        if (!AppContainer.providerConfigured()) {
            fail("JARVIS needs an AI provider first. Open Settings and enter an endpoint, a model and your API key.")
            return
        }
        val input = SpeechInput(context, inputCallback)
        if (!input.isAvailable()) {
            fail(
                "Speech recognition isn't available on this device. " +
                    "Make sure Google's speech services (or another recognizer) is installed and enabled."
            )
            return
        }
        speechInput = input
        speechOutput = SpeechOutput(context, outputListener)

        machine.transition(CallState.LISTENING)
        startTimer()
        beginListening()
    }

    private fun beginListening() {
        if (machine.state.value != CallState.LISTENING) return
        _partialText.value = ""
        _audioLevel.value = 0f
        if (_muted.value) return
        speechInput?.start()
    }

    private fun handleNoSpeech() {
        noSpeechStreak++
        if (noSpeechStreak >= MAX_SILENT_RESTARTS) {
            speechInput?.stop()
            fail("I didn't hear anything. Tap Try again when you're ready to talk.")
        } else {
            beginListening()
        }
    }

    private fun handleUtterance(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            handleNoSpeech()
            return
        }
        if (!machine.transition(CallState.PROCESSING)) return

        noSpeechStreak = 0
        speechInput?.stop()
        _partialText.value = ""
        _audioLevel.value = 0f
        _errorMessage.value = null
        addLine(Speaker.USER, clean)

        val myGeneration = ++generation
        requestJob?.cancel()
        requestJob = viewModelScope.launch {
            val result = agent.respond(clean)
            if (myGeneration != generation) return@launch // interrupted or call ended meanwhile
            when (result) {
                is AiResult.Success -> {
                    agent.record(clean, result.text)
                    addLine(Speaker.JARVIS, result.text)
                    speakReply(result.text, myGeneration)
                }
                is AiResult.Failure -> fail(result.message)
            }
        }
    }

    private fun speakReply(text: String, token: Long) {
        if (!machine.transition(CallState.SPEAKING)) return
        val output = speechOutput
        if (output == null) {
            outputListener.onFinished(token)
            return
        }
        output.speak(SpeechText.chunks(text), token)
    }

    /** Stops speech, or cancels a request that is still waiting for the AI, then listens again. */
    fun interrupt() {
        when (machine.state.value) {
            CallState.SPEAKING -> {
                generation++
                speechOutput?.stop()
                machine.transition(CallState.LISTENING)
                beginListening()
            }
            CallState.PROCESSING -> {
                generation++
                requestJob?.cancel()
                requestJob = null
                machine.transition(CallState.LISTENING)
                beginListening()
            }
            else -> Unit
        }
    }

    fun toggleMute() {
        val nowMuted = !_muted.value
        _muted.value = nowMuted
        if (nowMuted) {
            speechInput?.stop()
            _partialText.value = ""
            _audioLevel.value = 0f
        } else if (machine.state.value == CallState.LISTENING) {
            beginListening()
        }
    }

    fun endCall() {
        if (!machine.transition(CallState.ENDING)) return
        generation++
        requestJob?.cancel()
        requestJob = null
        timerJob?.cancel()
        timerJob = null
        speechInput?.stop()
        speechInput = null
        speechOutput?.shutdown()
        speechOutput = null

        val lines = _transcript.value
        if (lines.isNotEmpty()) {
            AppContainer.conversationRepository.add(
                ConversationRecord(UUID.randomUUID().toString(), startedAtMillis, lines)
            )
        }
        _muted.value = false
        _partialText.value = ""
        _audioLevel.value = 0f
        machine.transition(CallState.IDLE)
    }

    private fun fail(message: String) {
        _errorMessage.value = message
        machine.transition(CallState.ERROR)
    }

    private fun addLine(speaker: Speaker, text: String) {
        _transcript.value = _transcript.value + TranscriptLine(speaker, text)
    }

    private fun startTimer() {
        if (timerJob?.isActive == true) return
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _durationSeconds.value = _durationSeconds.value + 1
            }
        }
    }

    override fun onCleared() {
        endCall()
    }

    companion object {
        private const val MAX_SILENT_RESTARTS = 4
    }
}
