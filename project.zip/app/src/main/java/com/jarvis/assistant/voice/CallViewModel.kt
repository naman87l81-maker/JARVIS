package com.jarvis.assistant.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.di.AppContainer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CallViewModel : ViewModel() {
    private val voiceEngine: VoiceEngine = AppContainer.voiceEngine
    private val machine = CallStateMachine()
    private var timerJob: Job? = null

    val state: StateFlow<CallState> = machine.state

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0)
    val durationSeconds: StateFlow<Int> = _durationSeconds.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    fun startCall() {
        // Rejected unless IDLE, so a second session can never start.
        if (!machine.transition(CallState.CONNECTING)) return
        _errorMessage.value = null
        _durationSeconds.value = 0

        val reason = voiceEngine.unavailableReason()
        if (reason != null) {
            _errorMessage.value = reason
            machine.transition(CallState.ERROR)
            return
        }
        machine.transition(CallState.LISTENING)
        startTimer()
    }

    fun toggleMute() {
        _muted.value = !_muted.value
    }

    fun stopSpeech() {
        if (machine.state.value == CallState.SPEAKING) {
            machine.transition(CallState.LISTENING)
        }
    }

    fun endCall() {
        if (!machine.transition(CallState.ENDING)) return
        timerJob?.cancel()
        timerJob = null
        _muted.value = false
        // Later milestones: stop speech, cancel requests and release audio here.
        machine.transition(CallState.IDLE)
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _durationSeconds.value = _durationSeconds.value + 1
            }
        }
    }

    override fun onCleared() {
        endCall()
    }
}
