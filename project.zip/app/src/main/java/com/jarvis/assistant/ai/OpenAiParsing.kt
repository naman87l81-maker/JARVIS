package com.jarvis.assistant.ai

import org.json.JSONException
import org.json.JSONObject

/** Pure parsing helpers for OpenAI-compatible responses. */
object OpenAiParsing {

    /** Extracts the assistant text, or null if the body has no usable reply. */
    fun parseReply(body: String): String? {
        return try {
            val choices = JSONObject(body).optJSONArray("choices") ?: return null
            val message = choices.optJSONObject(0)?.optJSONObject("message") ?: return null
            if (message.isNull("content")) return null
            val text = stripThinking(message.optString("content", "")).trim()
            if (text.isEmpty()) null else text
        } catch (e: JSONException) {
            null
        }
    }

    fun parseModelIds(body: String): List<String> {
        return try {
            val data = JSONObject(body).optJSONArray("data") ?: return emptyList()
            val ids = mutableListOf<String>()
            for (i in 0 until data.length()) {
                val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                if (id.isNotBlank()) ids.add(id)
            }
            ids.sorted()
        } catch (e: JSONException) {
            emptyList()
        }
    }

    fun parseErrorMessage(body: String): String? {
        return try {
            val message = JSONObject(body).optJSONObject("error")?.optString("message", "").orEmpty()
            if (message.isBlank()) null else message.take(160)
        } catch (e: JSONException) {
            null
        }
    }

    /** Some reasoning models wrap their private thinking in <think> tags; never speak it. */
    fun stripThinking(text: String): String =
        text.replace(Regex("(?s)<think>.*?</think>"), "")

    /** Chat models only: hides speech-to-text, text-to-speech and safety-classifier models. */
    fun isChatModel(id: String): Boolean {
        val lower = id.lowercase()
        return listOf("whisper", "tts", "guard", "orpheus", "embed").none { lower.contains(it) }
    }
}
