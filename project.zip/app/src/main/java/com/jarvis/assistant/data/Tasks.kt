package com.jarvis.assistant.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class TaskStatus {
    QUEUED,
    RUNNING,
    WAITING_FOR_PERMISSION,
    WAITING_FOR_APPROVAL,
    COMPLETED,
    FAILED,
    CANCELLED
}

val TaskStatus.isActive: Boolean
    get() = this == TaskStatus.QUEUED ||
        this == TaskStatus.RUNNING ||
        this == TaskStatus.WAITING_FOR_PERMISSION ||
        this == TaskStatus.WAITING_FOR_APPROVAL

data class TaskRecord(
    val id: String,
    val instruction: String,
    val type: String,
    val createdAtMillis: Long,
    val status: TaskStatus,
    val progress: Float = 0f,
    val resultSummary: String? = null,
    val error: String? = null
)

/** In-memory task history. Room persistence arrives in a later milestone. */
class TaskRepository {
    private val _tasks = MutableStateFlow<List<TaskRecord>>(emptyList())
    val tasks: StateFlow<List<TaskRecord>> = _tasks.asStateFlow()

    fun add(task: TaskRecord) {
        _tasks.update { current -> listOf(task) + current }
    }

    fun updateStatus(
        id: String,
        status: TaskStatus,
        resultSummary: String? = null,
        error: String? = null
    ) {
        _tasks.update { current ->
            current.map { task ->
                if (task.id == id) {
                    task.copy(
                        status = status,
                        resultSummary = resultSummary ?: task.resultSummary,
                        error = error ?: task.error
                    )
                } else {
                    task
                }
            }
        }
    }

    fun clear() {
        _tasks.value = emptyList()
    }
}
