package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.data.AppSettings
import com.jarvis.assistant.data.ThemeMode
import com.jarvis.assistant.di.AppContainer

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val mode by AppSettings.themeMode.collectAsState()
    val tasks by AppContainer.taskRepository.tasks.collectAsState()

    ScreenScaffold(scrollable = true) {
        ScreenHeader(title = "Settings", onBack = onBack)
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Appearance") {
                ThemeMode.values().forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = mode == option,
                                onClick = { AppSettings.setThemeMode(option) },
                                role = Role.RadioButton
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = mode == option, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(option.label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Text(
                    "Applies right away. Reset when the app closes until saved settings are added.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionCard("AI provider and model") {
                Text(
                    "Not available yet. Provider, model and key setup arrive in Milestone 3.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = {}, enabled = false) { Text("Set up provider") }
            }

            SectionCard("Voice") {
                Text(
                    "Not available yet. Voice settings arrive in Milestone 2.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = {}, enabled = false) { Text("Voice settings") }
            }

            SectionCard("Privacy and data") {
                Text(
                    "This version makes no network requests and has no internet permission. " +
                        "Task history lives in memory only and is lost when the app closes.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(
                    onClick = { AppContainer.taskRepository.clear() },
                    enabled = tasks.isNotEmpty()
                ) { Text("Delete task history") }
            }

            SectionCard("About") {
                StatusRow("Version", "0.1.0 (Milestone 1)")
                StatusRow("Build", "Foundation only")
            }
        }
    }
}
