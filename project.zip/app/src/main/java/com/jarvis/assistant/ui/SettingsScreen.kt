package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ai.ProviderStatus
import com.jarvis.assistant.data.AppSettings
import com.jarvis.assistant.data.ThemeMode
import com.jarvis.assistant.di.AppContainer

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val mode by AppSettings.themeMode.collectAsState()
    val tasks by AppContainer.taskRepository.tasks.collectAsState()
    val conversations by AppContainer.conversationRepository.conversations.collectAsState()
    val lastRequest by ProviderStatus.last.collectAsState()

    ScreenScaffold(scrollable = true) {
        ScreenHeader(title = "Settings", onBack = onBack)
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("AI provider") {
                Text(
                    "Works with any OpenAI-compatible service. Free plans have limits and can change.",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.useGroqPreset() }) { Text("Use Groq") }
                    OutlinedButton(onClick = { viewModel.useOpenRouterPreset() }) { Text("Use OpenRouter") }
                }
                OutlinedTextField(
                    value = viewModel.endpoint,
                    onValueChange = { viewModel.endpoint = it },
                    label = { Text("Endpoint (https://...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = viewModel.model,
                    onValueChange = { viewModel.model = it },
                    label = { Text("Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = viewModel.keyInput,
                    onValueChange = { viewModel.keyInput = it },
                    label = { Text(if (viewModel.hasKey) "API key (saved, enter a new one to replace)" else "API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                StatusRow("Key stored", if (viewModel.hasKey) "Yes, encrypted on this device" else "No")
                StatusRow("Last request", lastRequest)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.save() }, enabled = !viewModel.busy) { Text("Save") }
                    OutlinedButton(onClick = { viewModel.testConnection() }, enabled = !viewModel.busy) {
                        Text("Test connection")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.loadModels() }, enabled = !viewModel.busy) {
                        Text("List models")
                    }
                    OutlinedButton(onClick = { viewModel.removeKey() }, enabled = viewModel.hasKey && !viewModel.busy) {
                        Text("Remove key")
                    }
                }
                if (viewModel.busy) Text("Working...", style = MaterialTheme.typography.bodyMedium)
                val message = viewModel.message
                if (message != null) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (viewModel.messageIsError) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.primary
                        }
                    )
                }
                viewModel.models.take(40).forEach { id ->
                    TextButton(onClick = { viewModel.pickModel(id) }) { Text(id) }
                }
            }

            SectionCard("Appearance") {
                ThemeMode.values().forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = mode == option,
                                onClick = { AppSettings.setThemeMode(option) },
                                role = Role.RadioButton
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = mode == option, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(option.label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Text(
                    "Resets when the app closes until saved settings are added.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            SectionCard("Privacy and data") {
                Text(
                    "Your voice: Android's speech service turns it into text. Depending on your device, " +
                        "that may be done by Google's servers. JARVIS cannot control this.\n\n" +
                        "Your messages: the text of what you and JARVIS say is sent to the endpoint above. " +
                        "Nothing else is sent, and no screen or file content is shared.\n\n" +
                        "Your API key: stored encrypted with the Android Keystore and sent only to the endpoint above. " +
                        "No app can guarantee a key is safe on a compromised device.\n\n" +
                        "History: conversations and tasks are kept in memory only and are lost when the app closes.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(
                    onClick = {
                        AppContainer.taskRepository.clear()
                        AppContainer.conversationRepository.clear()
                    },
                    enabled = tasks.isNotEmpty() || conversations.isNotEmpty()
                ) { Text("Delete conversation and task history") }
            }

            SectionCard("About") {
                StatusRow("Version", "0.2.0 (Milestone 2)")
                StatusRow("Replies", "Turn-based, not streamed")
            }
        }
    }
}
