package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.data.TaskRecord
import com.jarvis.assistant.data.TaskStatus
import com.jarvis.assistant.di.AppContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun statusLabel(status: TaskStatus): String = when (status) {
    TaskStatus.QUEUED -> "Queued"
    TaskStatus.RUNNING -> "Running"
    TaskStatus.WAITING_FOR_PERMISSION -> "Waiting for permission"
    TaskStatus.WAITING_FOR_APPROVAL -> "Waiting for approval"
    TaskStatus.COMPLETED -> "Completed"
    TaskStatus.FAILED -> "Failed"
    TaskStatus.CANCELLED -> "Cancelled"
}

private fun formatTime(millis: Long): String =
    SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(millis))

@Composable
fun TaskRow(task: TaskRecord) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = task.instruction,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = statusLabel(task.status) + " at " + formatTime(task.createdAtMillis),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val error = task.error
        if (error != null) {
            Text(
                text = error,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
fun TasksScreen(onBack: () -> Unit) {
    val tasks by AppContainer.taskRepository.tasks.collectAsState()

    ScreenScaffold {
        ScreenHeader(title = "Tasks", onBack = onBack)
        if (tasks.isEmpty()) {
            Text(
                text = "No tasks yet. When JARVIS runs a task for you, its progress and result show up here.",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tasks, key = { it.id }) { task -> TaskRow(task) }
            }
        }
    }
}
