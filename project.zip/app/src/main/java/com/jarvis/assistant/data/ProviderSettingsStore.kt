package com.jarvis.assistant.data

import android.content.Context

/** Non-secret provider settings. The API key lives in SecretStore, never here. */
class ProviderSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_provider", Context.MODE_PRIVATE)

    var endpoint: String
        get() = prefs.getString("endpoint", GROQ_ENDPOINT) ?: GROQ_ENDPOINT
        set(value) {
            prefs.edit().putString("endpoint", value).apply()
        }

    var model: String
        get() = prefs.getString("model", GROQ_DEFAULT_MODEL) ?: GROQ_DEFAULT_MODEL
        set(value) {
            prefs.edit().putString("model", value).apply()
        }

    companion object {
        const val GROQ_ENDPOINT = "https://api.groq.com/openai/v1"
        // A starting suggestion only. Model availability changes; pick a current one in Settings.
        const val GROQ_DEFAULT_MODEL = "llama-3.3-70b-versatile"
        const val OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1"
    }
}
