package com.jarvis.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CallStateMachineTest {

    @Test
    fun startsIdle() {
        assertEquals(CallState.IDLE, CallStateMachine().state.value)
    }

    @Test
    fun cannotSkipConnecting() {
        val machine = CallStateMachine()
        assertFalse(machine.transition(CallState.LISTENING))
        assertEquals(CallState.IDLE, machine.state.value)
    }

    @Test
    fun secondSessionIsRejected() {
        val machine = CallStateMachine()
        assertTrue(machine.transition(CallState.CONNECTING))
        assertFalse(machine.transition(CallState.CONNECTING))
    }

    @Test
    fun happyPathReturnsToIdle() {
        val machine = CallStateMachine()
        assertTrue(machine.transition(CallState.CONNECTING))
        assertTrue(machine.transition(CallState.LISTENING))
        assertTrue(machine.transition(CallState.PROCESSING))
        assertTrue(machine.transition(CallState.SPEAKING))
        assertTrue(machine.transition(CallState.LISTENING))
        assertTrue(machine.transition(CallState.ENDING))
        assertTrue(machine.transition(CallState.IDLE))
        assertEquals(CallState.IDLE, machine.state.value)
    }

    @Test
    fun endingOnlyLeadsToIdle() {
        val machine = CallStateMachine()
        machine.transition(CallState.CONNECTING)
        machine.transition(CallState.ENDING)
        assertFalse(machine.transition(CallState.LISTENING))
        assertTrue(machine.transition(CallState.IDLE))
    }

    @Test
    fun everyActiveStateCanEnd() {
        val activeStates = CallState.values().filter {
            it != CallState.IDLE && it != CallState.ENDING
        }
        activeStates.forEach { state ->
            val allowed = CallStateMachine.ALLOWED[state]
            assertTrue("$state must be able to end", allowed != null && allowed.contains(CallState.ENDING))
        }
    }
}
