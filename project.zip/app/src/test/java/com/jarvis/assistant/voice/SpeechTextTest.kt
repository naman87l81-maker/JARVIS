package com.jarvis.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechTextTest {

    @Test
    fun stripsMarkdownSymbols() {
        assertEquals("Hello world", SpeechText.cleanForSpeech("**Hello** `world`"))
    }

    @Test
    fun splitsIntoSentences() {
        val chunks = SpeechText.chunks("Hello there. How are you? Fine!")
        assertEquals(listOf("Hello there.", "How are you?", "Fine!"), chunks)
    }

    @Test
    fun emptyTextGivesNoChunks() {
        assertTrue(SpeechText.chunks("  ").isEmpty())
    }

    @Test
    fun longSentencesAreSplitUnderTheLimit() {
        val long = (1..200).joinToString(" ") { "word$it" }
        val chunks = SpeechText.chunks(long, maxLen = 100)
        assertTrue(chunks.size > 1)
        assertTrue(chunks.all { it.length <= 100 })
    }
}
