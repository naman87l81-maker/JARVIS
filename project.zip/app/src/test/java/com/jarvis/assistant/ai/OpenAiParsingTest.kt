package com.jarvis.assistant.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OpenAiParsingTest {

    @Test
    fun parsesNormalReply() {
        val body = """{"choices":[{"message":{"role":"assistant","content":"Hi there"}}]}"""
        assertEquals("Hi there", OpenAiParsing.parseReply(body))
    }

    @Test
    fun hidesThinkingText() {
        val body = """{"choices":[{"message":{"content":"<think>secret plan</think>Answer"}}]}"""
        assertEquals("Answer", OpenAiParsing.parseReply(body))
    }

    @Test
    fun emptyOrBrokenRepliesAreNull() {
        assertNull(OpenAiParsing.parseReply("""{"choices":[]}"""))
        assertNull(OpenAiParsing.parseReply("""{"choices":[{"message":{"content":""}}]}"""))
        assertNull(OpenAiParsing.parseReply("not json"))
    }

    @Test
    fun parsesModelIdsSorted() {
        val body = """{"data":[{"id":"b-model"},{"id":"a-model"}]}"""
        assertEquals(listOf("a-model", "b-model"), OpenAiParsing.parseModelIds(body))
    }

    @Test
    fun parsesProviderErrorMessage() {
        val body = """{"error":{"message":"model has been decommissioned"}}"""
        assertEquals("model has been decommissioned", OpenAiParsing.parseErrorMessage(body))
        assertNull(OpenAiParsing.parseErrorMessage("oops"))
    }

    @Test
    fun filtersNonChatModels() {
        assertTrue(OpenAiParsing.isChatModel("llama-3.3-70b-versatile"))
        assertFalse(OpenAiParsing.isChatModel("whisper-large-v3"))
        assertFalse(OpenAiParsing.isChatModel("meta-llama/llama-guard-4-12b"))
    }
}
