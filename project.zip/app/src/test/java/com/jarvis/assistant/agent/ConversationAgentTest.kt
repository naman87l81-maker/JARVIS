package com.jarvis.assistant.agent

import com.jarvis.assistant.ai.AiProvider
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.ai.ChatMessage
import com.jarvis.assistant.ai.ModelsResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class ConversationAgentTest {

    private class FakeProvider : AiProvider {
        var lastMessages: List<ChatMessage> = emptyList()

        override suspend fun chat(messages: List<ChatMessage>): AiResult {
            lastMessages = messages
            return AiResult.Success("ok")
        }

        override suspend fun listModels(): ModelsResult = ModelsResult.Failure("not used")
    }

    @Test
    fun sendsSystemPromptFirstAndUserLast() = runBlocking {
        val provider = FakeProvider()
        ConversationAgent(provider).respond("hello")
        assertEquals("system", provider.lastMessages.first().role)
        assertEquals(ChatMessage("user", "hello"), provider.lastMessages.last())
    }

    @Test
    fun unrecordedReplyLeavesNoHistory() = runBlocking {
        val provider = FakeProvider()
        val agent = ConversationAgent(provider)
        agent.respond("first")
        agent.respond("second")
        // system + user only: the first exchange was never recorded
        assertEquals(2, provider.lastMessages.size)
    }

    @Test
    fun recordedReplyIsSentNextTime() = runBlocking {
        val provider = FakeProvider()
        val agent = ConversationAgent(provider)
        agent.record("first", "answer")
        agent.respond("second")
        assertEquals(listOf("system", "user", "assistant", "user"), provider.lastMessages.map { it.role })
    }

    @Test
    fun historyIsBounded() = runBlocking {
        val provider = FakeProvider()
        val agent = ConversationAgent(provider)
        repeat(50) { agent.record("q$it", "a$it") }
        agent.respond("now")
        assertEquals(1 + ConversationAgent.MAX_HISTORY_MESSAGES + 1, provider.lastMessages.size)
    }
}
