package com.jarvis.assistant.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskRepositoryTest {

    private fun task(id: String) = TaskRecord(
        id = id,
        instruction = "test $id",
        type = "test",
        createdAtMillis = 0L,
        status = TaskStatus.QUEUED
    )

    @Test
    fun newestTaskComesFirst() {
        val repo = TaskRepository()
        repo.add(task("a"))
        repo.add(task("b"))
        assertEquals(listOf("b", "a"), repo.tasks.value.map { it.id })
    }

    @Test
    fun updateStatusChangesOnlyTheTarget() {
        val repo = TaskRepository()
        repo.add(task("a"))
        repo.add(task("b"))
        repo.updateStatus("a", TaskStatus.FAILED, error = "boom")
        val byId = repo.tasks.value.associateBy { it.id }
        assertEquals(TaskStatus.FAILED, byId.getValue("a").status)
        assertEquals("boom", byId.getValue("a").error)
        assertEquals(TaskStatus.QUEUED, byId.getValue("b").status)
    }

    @Test
    fun clearRemovesEverything() {
        val repo = TaskRepository()
        repo.add(task("a"))
        repo.clear()
        assertTrue(repo.tasks.value.isEmpty())
    }

    @Test
    fun activeStatusesAreFlaggedCorrectly() {
        assertTrue(TaskStatus.RUNNING.isActive)
        assertTrue(TaskStatus.WAITING_FOR_APPROVAL.isActive)
        assertEquals(false, TaskStatus.COMPLETED.isActive)
        assertEquals(false, TaskStatus.CANCELLED.isActive)
    }
}
