# Security (Milestone 1)

- No permissions are declared. The app has no internet and no microphone access yet.
- No API keys exist in this project. Keys will be entered by the user at runtime (Milestone 3),
  stored with Android Keystore-backed encryption, never committed, never logged.
- Client-held keys cannot be guaranteed safe on a compromised device; a server-side proxy is the safer option.
