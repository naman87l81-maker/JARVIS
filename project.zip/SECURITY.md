# Security (Milestone 2)

Permissions: INTERNET (to reach the AI provider you configure) and RECORD_AUDIO (only requested when a call starts).

API key:
- Entered by you in Settings, never in source code, the repo or the APK.
- Stored encrypted with an AES-GCM key held in the Android Keystore. This protects it at rest;
  it cannot be guaranteed safe on a fully compromised device.
- Sent only to the endpoint you configured, and only over https:// (other endpoints are refused).
- Not written to logs. Backups are disabled (allowBackup=false).

Data leaving the device:
- Your speech is converted to text by Android's speech service. Depending on the device that may be
  done by Google's servers; the app cannot control this.
- The text of the conversation goes to your configured AI endpoint. Nothing else is sent.

Microphone: used only while a call is open and unmuted. The call ends automatically if the app leaves the screen.
Safer deployment later: a small backend proxy that holds the key server-side.
