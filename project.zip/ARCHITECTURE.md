# Architecture (Milestone 1)

Package `com.jarvis.assistant`:
- `ui/`: Compose screens, navigation (`JarvisApp`), shared components, `theme/`
- `voice/`: `CallState` + `CallStateMachine`, `VoiceEngine` interface, `CallViewModel`
- `data/`: `TaskRecord`/`TaskRepository` (in-memory), `AppSettings` (in-memory)
- `di/`: `AppContainer`, a plain object that wires dependencies

Planned (later milestones): `ai/`, `agent/`, `tools/`, `files/`, `research/`, `permissions/`, `screen/`, `security/`.
Screens never call APIs or touch files directly; they read state from ViewModels and repositories.
