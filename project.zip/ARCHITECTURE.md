# Architecture (Milestone 2)

Package `com.jarvis.assistant`:
- `ui/`: Compose screens, navigation, theme, SettingsViewModel
- `voice/`: CallStateMachine, CallViewModel (runs the call), SpeechInput, SpeechOutput, SpeechText
- `agent/`: ConversationAgent (system prompt, bounded history; talk only, no tools yet)
- `ai/`: AiProvider interface, OpenAiCompatibleProvider (OkHttp, retries, error mapping), parsing, ProviderStatus
- `security/`: SecretStore (Android Keystore + AES-GCM)
- `data/`: tasks, conversations, provider settings, theme (all in-memory except provider settings)
- `di/`: AppContainer wiring, initialised from JarvisApplication

Call loop: LISTENING -> (final sentence) PROCESSING -> SPEAKING -> LISTENING.
Every interruption, cancellation or end of call bumps a generation counter; results carrying an older
value are ignored, so old replies are never spoken.
