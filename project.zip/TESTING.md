# Testing

Unit tests (run in CI with `gradle testDebugUnitTest`):
CallStateMachineTest, TaskRepositoryTest, SpeechTextTest, OpenAiParsingTest, ConversationAgentTest.

Manual device checklist for Milestone 2 (not yet done):
1. Call with microphone denied: explanation shown; Allow works; Open app settings works.
2. Speak a sentence: partial text appears, then JARVIS replies in text and voice.
3. Interrupt while JARVIS is speaking: speech stops immediately and it listens again.
4. Interrupt while "Thinking": request is cancelled and it listens again.
5. End call: speech stops, mic indicator off, call appears under Recent conversations.
6. Airplane mode: clear network error, call stays open.
7. Wrong API key: "key was rejected (401)" message.
8. Leave the app during a call: the call ends.

Not tested at all: rate-limit handling against a real provider, long conversations, other languages.
