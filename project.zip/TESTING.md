# Testing

Automated (unit, run in CI): `CallStateMachineTest`, `TaskRepositoryTest`.
Run locally: `gradle testDebugUnitTest`.

Not yet tested: UI on a device, instrumentation tests, anything involving voice, network or files.
Status as of Milestone 1: tests written, not yet run.
